from .loader import _Loader


__all__ = ["Loader"]


Loader = _Loader
