#!/usr/bin/env python
# encoding: utf-8

__all__ = ['DesKey']

from .base import DesKey
